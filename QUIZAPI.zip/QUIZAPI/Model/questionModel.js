const mongoose = require("mongoose");
const slugify = require("slugify");
// const validator = require('validator');

const questionSchema = new mongoose.Schema({
  question: {
    type: String,
    required: true,
    unique: true,
    trim: true,
  },
  answers: {
    type: Array,
    required: true,
    unique: true,
    trim: true,
  },
  correctIndex: {
    type: Number,
    default: 4.5,
    min: [0, "Answer must be greater 0"],
    max: [3, "Answer must be lesser 4"],
  },
});

const Question = mongoose.model('Question', questionSchema);

module.exports = Question;
