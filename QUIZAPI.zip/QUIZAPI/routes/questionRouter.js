const express = require('express')
const questionController = require('./../controllers/questionHandler');
const authController = require('./../controllers/authHandler')
const router = express.Router();
router.param('id', questionController.CHECKID);
router.route("/").get(authController.protect,questionController.getAllQuestions).post(questionController.postQuestion);
router.route("/:id").get(questionController.getAQuestion).patch(authController.protect,authController.restrictTo('admin','lead-guide'),questionController.updateQuestion).delete(authController.protect,authController.restrictTo('admin','lead-guide'),questionController.deleteQuestion);

module.exports =router;