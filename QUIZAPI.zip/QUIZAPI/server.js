const express = require("express");
const app = express();
const mongoose = require('mongoose');
const morgan = require('morgan');
const questionRouter = require('./routes/questionRouter')
const userRouter = require('./routes/userRouter');
require("dotenv").config();
var bodyParser = require("body-parser");

//DB
const DB = process.env.DATABASE.replace(
    '<PASSWORD>',
    process.env.DATABASE_PASSWORD
  );
  mongoose.set("strictQuery", false);
  mongoose.connect(`${DB}`) .then(() => console.log('DB connection successful!'));;

app.use(morgan('dev'));
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);
app.use(bodyParser.json());


///ROUTERS
app.use('/api/users', userRouter);
app.use('/api/questions',questionRouter)
app.all('*',(req,res,next) =>{
    res.status(404).json({
        status : 'fail',
        message : `Can't find ${req.originalUrl} on this server!`    })
});
app.listen(process.env.PORT, () => {
  console.log(`Server is created at ${process.env.PORT}`);
});
