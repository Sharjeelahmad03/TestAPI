const express = require("express");
const app = express();
const mongoose = require('mongoose');
const morgan = require('morgan');
const Question = require('./Model/questionModel');
const User = require('./Model/userModel');

const questionRouter = require('./routes/questionRouter')
require("dotenv").config();
var bodyParser = require("body-parser");
const fs = require('fs');


const users = JSON.parse(fs.readFileSync(`${__dirname}//user.json`));

const DB = process.env.DATABASE.replace(
    '<PASSWORD>',
    process.env.DATABASE_PASSWORD
  );
  console.log(DB);
  mongoose.set("strictQuery", false);
  mongoose.connect(`${DB}`) .then(() => console.log('DB connection successful!'));;

app.use(morgan('dev'));
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);
app.use(bodyParser.json());

app.get('/', async(req,res)=> {
    try {
        await User.create(users);
        console.log('Data successfully loaded');
    } catch (error) {
        console.log(error);
    }
})
app.listen(process.env.PORT, () => {
    console.log(`Server is created at ${process.env.PORT}`);
  });
