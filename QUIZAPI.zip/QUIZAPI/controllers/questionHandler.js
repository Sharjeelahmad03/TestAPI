const Question = require('./../Model/questionModel');

// const fs = require("fs");
// const questions = JSON.parse(fs.readFileSync(`${__dirname}/../data.json`));

exports.CHECKID = (req, res, next, val) => {
  if (req.params.id * 1 > questions.length) {
    return res.status(404).json({
      status: "fail",
      message: "Invalid ID",
    });
  }
  next(val);
};
exports.getAllQuestions = async(req, res) => {
  try {
    const questions = await Question.find();
    // SEND RESPONSE
    res.status(200).json({
      status: "success",
      results: questions.length,
      data: {
        questions,
      },
    });
    // SEND ERROR
  } catch (err) {
    res.status(404).json({
      status: "fail",
      message: err,
    });
  }
};
exports.postQuestion = async(req, res) => {
  try {
    const newQuestion = await Question.create(req.body);
    // SEND RESPONSE
    res.status(201).json({
        status: 'success',
        data: {
          question: newQuestion
        }
      });
  } catch (err) {
    res.status(400).json({
      status: "fail",
      message: err,
    });
  }
};
exports.getAQuestion = async(req, res) => {
  try {

    const question = await Question.findById(req.params.id);
        // SEND RESPONSE
    res.status(200).json({
      status: "success",
      data: {
        question,
      },
    });
  } catch (err) {
    res.status(404).json({
      status: "fail",
      message: err,
    });
  }
};
exports.updateQuestion = async (req,res) => {
    try{
        const question = await Question.findByIdAndUpdate(req.params.id, req.body, {
            new: true,
            runValidators: true
          });
          res.status(200).json({
            status: 'success',
            data: {
                question
            }
          });
    }catch(err){
        res.status(404).json({
            status: 'fail',
            message: err
          });
    }
}
exports.deleteQuestion = async(req, res) => {
  try {
    
   const question= await Question.findByIdAndDelete(req.params.id);
    if (!question) {
        return next(new AppError('No question found with that ID', 404));
      }
    
    res.status(204).json({
      status: "success",
      data: {
        question: null,
      },
    });
  } catch (err) {
    res.status(404).json({
      status: "fail",
      message: err,
    });
  }
};
